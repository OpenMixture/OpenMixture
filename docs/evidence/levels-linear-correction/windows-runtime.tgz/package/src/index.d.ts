// Runtime build sha256:b01aef61feb3e1faa9a367af95c3462e1276ff8943fd9ce6b2403c94f4734502; API schema 3
import type { RuntimeModule } from './types.js';
export type * from './types.js';
import { MixtureRuntimeError } from './runtime.js';
export { MixtureRuntimeError };
/** Import is inert. Only this call imports generated glue and initializes WASM. */
export declare function loadRuntime(options?: {
    wasm?: URL | string | Uint8Array;
}): Promise<RuntimeModule>;
