import type { BrowserFailure, BuildInfo, Diagnostic, RuntimeModule, SafetyLimits, ResourceLimits } from './types.js';
import type { BindingRequest, Bindings, Failure } from './bindings.js';
/** Structured public failures preserve engine diagnostics independently of browser failures. */
export declare class MixtureRuntimeError extends Error {
    readonly operation: string;
    readonly diagnostics: Diagnostic[];
    readonly browserFailure?: BrowserFailure;
    readonly evidence?: unknown;
    constructor(operation: string, failure: Failure);
    get code(): string | undefined;
}
export declare function browserError(operation: string, code: string, message: string, evidence?: unknown): MixtureRuntimeError;
export declare function normalizeError(operation: string, error: unknown): MixtureRuntimeError;
export declare function captureOptions(options: unknown, operation: string, allowed: readonly string[]): Record<string, unknown>;
export declare function captureRequest(options: unknown | undefined, operation: string, defaultLimits: Readonly<SafetyLimits>, defaultResources: Readonly<ResourceLimits>): BindingRequest;
export declare function captureSource(source: unknown, limit: bigint, operation: string): Uint8Array<ArrayBuffer>;
export declare function copyBytes(source: unknown, operation: string, limit?: bigint): Uint8Array<ArrayBuffer>;
export declare function createRuntimeModule(bindings: Bindings, expectedBuild: BuildInfo): RuntimeModule;
