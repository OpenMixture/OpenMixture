// Runtime build sha256:a5d5d234cc2fa885c02dffccfdcc15d6f8b809e507cc17055acf1cde45778ba9; API schema 3
import type { RuntimeModule } from './types.js';
export type * from './types.js';
import { MixtureRuntimeError } from './runtime.js';
export { MixtureRuntimeError };
/** Import is inert. Only this call imports generated glue and initializes WASM. */
export declare function loadRuntime(options?: {
    wasm?: URL | string | Uint8Array;
}): Promise<RuntimeModule>;
