export type Source = string | Uint8Array;
export type ChannelId = 'baseColor' | 'normal' | 'roughness' | 'metallic' | 'height' | 'ambientOcclusion' | 'opacity' | 'emissive';
export type PortKind = 'color' | 'scalar' | 'normal';
export type ParameterValue = number | string | [number, number, number, number];
export type ProjectedValue = null | boolean | number | bigint | string | ProjectedValue[] | {
    [key: string]: ProjectedValue;
};
export interface SafetyLimits {
    decodedBytes: bigint;
    nodes: bigint;
    edges: bigint;
    exposedParameters: bigint;
    outputDimension: bigint;
    requestedOutputs: bigint;
    transientBytes: bigint;
}
export interface ResourceLimits {
    resourceCount: bigint;
    resourcePixels: bigint;
    resourceBytes: bigint;
}
export interface PackageLimits {
    packageBytes: bigint;
    manifestBytes: bigint;
    packageBufferBytes: bigint;
}
export interface PackageOptions {
    limits?: Partial<SafetyLimits>;
    resourceLimits?: Partial<ResourceLimits>;
    packageLimits?: Partial<PackageLimits>;
}
export interface PackageRenderRequest extends Omit<RenderRequest, 'resources'> {
    packageLimits?: Partial<PackageLimits>;
}
export interface PackageInspection {
    schemaVersion: 1;
    packageVersion: 1;
    packageSha256: string;
    packageBytes: bigint;
    sourceSha256: string;
    sourceBytes: bigint;
    resources: Array<{
        id: string;
        path: string;
        width: number;
        height: number;
        format: 'rgba8-linear';
        bytesPerRow: bigint;
        byteLength: bigint;
        contentDigest: string;
    }>;
    buffers: {
        jsPackageBytes: bigint;
        rustPackageBytes: bigint;
        chargedBytes: bigint;
    };
}
export interface ImageBinding {
    id: string;
    width: number;
    height: number;
    format: 'rgba8-linear';
    bytesPerRow: number;
    data: Uint8Array;
}
export interface RenderRequest {
    size?: [number, number];
    channels?: ChannelId[];
    overrides?: Record<string, ParameterValue>;
    limits?: Partial<SafetyLimits>;
    resources?: ImageBinding[];
    resourceLimits?: Partial<ResourceLimits>;
}
export interface BuildInfo {
    runtimeVersion: string;
    apiSchemaVersion: number;
    engineVersion: string;
    engineRevision: string | null;
    engineDirty: boolean | null;
    buildId: string;
}
export interface Diagnostic {
    code: string;
    stage: string;
    severity: 'error' | 'warning' | 'info';
    message: string;
    nodeId?: string;
    portId?: string;
    parameterId?: string;
    documentPath?: string;
    evidence?: Record<string, ProjectedValue>;
    suggestion?: string;
}
export interface BrowserFailure {
    code: string;
    operation: string;
    message: string;
    evidence?: unknown;
    suggestion?: string;
}
export type ParameterKind = {
    type: 'float' | 'integer';
    min: number;
    max: number;
} | {
    type: 'resourceRef';
} | {
    type: 'color';
} | {
    type: 'enum';
    values: string[];
};
export interface ParameterContract {
    id: string;
    kind: ParameterKind;
    default: ParameterValue | null;
}
export interface PortDefault {
    kind: PortKind;
    value: number | number[];
}
export interface PortContract {
    id: string;
    kind: PortKind;
    default: PortDefault | null;
}
export interface NodeContract {
    typeId: string;
    version: number;
    label: string;
    description: string;
    inputs: PortContract[];
    outputs: PortContract[];
    parameters: ParameterContract[];
}
export interface Endpoint {
    nodeId: string;
    portId: string;
}
export type InputSource = {
    source: 'connected';
    from: Endpoint;
} | {
    source: 'default';
    value: PortDefault;
};
export interface MaterialChannel {
    id: ChannelId;
    kind: PortKind;
    input: InputSource;
}
export interface ExposedParameter {
    id: string;
    nodeId: string;
    nodeType: string;
    nodeVersion: number;
    parameterId: string;
    contract: ParameterContract;
    sourceValue: ParameterValue;
    effectiveValue: ParameterValue;
}
export interface PlanEstimates {
    resourceCount: bigint;
    resourceUploadBytes: bigint;
    resourceTextureBytes: bigint;
    resourceStagingBytes: bigint;
    textureCount: bigint;
    logicalTextureBytes: bigint;
    textureBytes: bigint;
    uniformBytes: bigint;
    paddedBytesPerRow: number;
    readbackBufferBytes: bigint;
    readbackBytes: bigint;
    cumulativeReadbackBytes: bigint;
    cumulativeBytes: bigint;
    peakBytes: bigint;
}
export interface RenderPlan {
    version: number;
    documentVersion: number;
    hash: string;
    size: [number, number];
    materialOutput: {
        id: string;
        typeId: string;
        version: number;
    };
    passes: Array<{
        id: number;
        origin: ProjectedValue;
        kernel: ProjectedValue;
        output: number;
        outputDesc: ProjectedValue;
        dispatch: [number, number, number];
    }>;
    outputs: Array<{
        channel: ChannelId;
        kind: PortKind;
        input: InputSource;
        resource: number;
    }>;
    allocation: {
        slots: Array<{
            width: number;
            height: number;
            format: 'rgba16float';
            kind: PortKind;
        }>;
        resourceSlots: number[];
        lastUses: number[];
    };
    imageResources: Array<{
        id: string;
        format: string;
        width: number;
        height: number;
        bytesPerRow: bigint;
        contentDigest: string;
    }>;
    estimates: PlanEstimates;
}
export interface Inspection {
    ok: true;
    diagnostics: Diagnostic[];
    documentVersion: number;
    plan: RenderPlan;
    exposedParameters: ExposedParameter[];
    materialChannels: MaterialChannel[];
}
export type ValidationResult = Inspection | {
    ok: false;
    diagnostics: Diagnostic[];
};
export interface RenderedChannel {
    channel: ChannelId;
    kind: PortKind;
    source: InputSource;
    size: [number, number];
    encoding: 'rgba8-srgb' | 'rgba8-linear';
    pixels: Uint8Array;
}
export interface RenderReport {
    planHash: string;
    adapter: Record<string, ProjectedValue>;
    size: [number, number];
    passCount: bigint;
    pipelineCache: {
        hits: number;
        misses: number;
        entries: bigint;
    };
    estimates: PlanEstimates;
    allocations: Record<string, bigint>;
    readbackBytes: bigint;
    mappedBytes: bigint;
    rgbaBytes: bigint;
    timings: Record<string, number>;
}
export interface RenderResult {
    documentVersion: number;
    plan: RenderPlan;
    channels: RenderedChannel[];
    report: RenderReport;
}
export interface GpuRuntime {
    readonly context: Record<string, ProjectedValue>;
    render(source: Source, request?: RenderRequest): Promise<RenderResult>;
    renderPackage(bytes: Uint8Array, request?: PackageRenderRequest): Promise<RenderResult>;
    destroy(): Promise<void>;
}
export interface RuntimeModule {
    getBuildInfo(): BuildInfo;
    getNodeCatalog(): NodeContract[];
    validate(source: Source, request?: RenderRequest): ValidationResult;
    inspect(source: Source, request?: RenderRequest): Inspection;
    inspectPackage(bytes: Uint8Array, options?: PackageOptions): PackageInspection;
    createGpu(options?: {
        powerPreference?: 'low-power' | 'high-performance';
    }): Promise<GpuRuntime>;
}
